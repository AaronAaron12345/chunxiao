import matplotlib.pyplot as plt
import networkx as nx
# 设置支持中文的字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
plt.rcParams['axes.unicode_minus'] = False    # 解决坐标轴负号显示问题

# 创建有向图
G = nx.DiGraph()

# 定义节点和位置，调整距离以避免重叠
nodes = {
    "图像采集模块": (0, 0),
    "图像处理与分析模块": (4, 0),     # 调整 x 位置
    "报警与控制模块": (8, -1),
    "数据存储与显示模块": (8, 1)
}

for node, pos in nodes.items():
    G.add_node(node, pos=pos)

# 添加边
edges = [
    ("图像采集模块", "图像处理与分析模块", "传输图像数据"),
    ("图像处理与分析模块", "报警与控制模块", "发送检测结果"),
    ("图像处理与分析模块", "数据存储与显示模块", "存储和显示数据"),
    ("报警与控制模块", "数据存储与显示模块", "更新报警状态")
]

for src, dst, label in edges:
    G.add_edge(src, dst, label=label)

# 设置节点位置
pos = nx.get_node_attributes(G, 'pos')

# 绘制图形
plt.figure(figsize=(14, 6), dpi=150)  # 设置更大的图像尺寸和高 DPI
ax = plt.gca()

# 绘制节点
for node in G.nodes:
    x, y = pos[node]
    # 绘制矩形，增大尺寸以完全包裹名称
    rect = plt.Rectangle((x - 1.0, y - 0.4), 2.8, 0.8, fill=True, facecolor="lightgrey", edgecolor="black", linewidth=1.5)
    ax.add_patch(rect)
    # 添加节点标签，进一步增大字体
    plt.text(x, y, node, ha="center", va="center", fontsize=16, fontweight="bold")  # 调整 fontsize 为 16

# 绘制边和边标签
for src, dst, label in edges:
    # 绘制边
    nx.draw_networkx_edges(G, pos, edgelist=[(src, dst)], arrows=True, arrowstyle="->", arrowsize=20, edge_color="black")
    # 添加边标签，略微偏移位置，增大字体
    mid_x = (pos[src][0] + pos[dst][0]) / 2
    mid_y = (pos[src][1] + pos[dst][1]) / 2 + 0.3  # 向上偏移一点
    plt.text(mid_x, mid_y, label, ha="center", va="center", fontsize=14, style="italic")  # 调整 fontsize 为 14

# 设置标题并增大字体
plt.title("系统架构图", fontsize=18, fontweight="bold")  # 调整标题 fontsize 为 18
plt.axis("off")
plt.show()
